from django.contrib import admin
from testapp.models import Doctor,Patient,Appointment

# Register your models here.
class DoctorAdmin(admin.ModelAdmin):
    list_display=['doctor_name','mobile_number','hospital_name','specialization','experience']


class PatientAdmin(admin.ModelAdmin):
    list_display=['patient_name','mobile_number','age','gender','address']


class AppointmentAdmin(admin.ModelAdmin):
    list_display=['doctor','patient','date_and_time']



admin.site.register(Doctor,DoctorAdmin)
admin.site.register(Patient,PatientAdmin)
admin.site.register(Appointment,AppointmentAdmin)
